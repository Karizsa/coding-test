﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using CodingExam.Models;
using CodingExam.Controllers;
using CodingExam;

namespace CodingExamTest
{
    [TestClass]
    public class UnitTest
    {
        [TestMethod]
        public void Test_GetAccount()
        {
            
            AccountController ac = new AccountController();


            var result = ac.GetAccount();
            

            Assert.IsNotNull(result);
           
        }

    }

}
