using System;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Linq;

namespace CodingExam.Models
{
    public partial class AccountDbContext : DbContext
    {
        public AccountDbContext()
            : base("name=Account")
        {
        }

        public virtual DbSet<vAccountDetail> vAccountDetails { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<vAccountDetail>()
                .Property(e => e.Loan_Status)
                .IsUnicode(false);
        }
    }
}
