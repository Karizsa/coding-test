namespace CodingExam.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class vAccountDetail
    {
        [Column("Transaction Date", TypeName = "date")]
        public DateTime? Transaction_Date { get; set; }

        [Column("Amount Paid")]
        public long? Amount_Paid { get; set; }

        public long? Balance { get; set; }

        [Key]
        [Column("Loan Status")]
        [StringLength(11)]
        public string Loan_Status { get; set; }
    }
}
